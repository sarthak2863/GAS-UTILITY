A surge in customer service requests is overwhelming a gas utility company. The current system's capacity is insufficient, resulting in prolonged wait times and subpar service for customers.

A Django application is proposed to facilitate consumer services for gas utilities. This platform will enable customers to submit service requests online, monitor the progress of their requests, and access their account details.

Moreover, the application will furnish customer support representatives with a dedicated tool for request management and customer assistance.
To run application use python3 manage.py runserver command
![image](https://github.com/3008Dhruv/GAS-UTILITY/assets/168810355/b9aeb568-c100-4e0a-b457-a001fa924d74)
![image](https://github.com/3008Dhruv/GAS-UTILITY/assets/168810355/f3e4ca85-32f9-4a07-ad12-dbfa8e222df1)
![image](https://github.com/3008Dhruv/GAS-UTILITY/assets/168810355/31d02255-1727-4e6e-af0f-b0e5041104a0)
![image](https://github.com/3008Dhruv/GAS-UTILITY/assets/168810355/e55c1099-8ad2-4f69-9c22-0680ee086429)
![image](https://github.com/3008Dhruv/GAS-UTILITY/assets/168810355/1a03baa4-979b-4122-8934-c764ffa4fc0f)
![image](https://github.com/3008Dhruv/GAS-UTILITY/assets/168810355/c969997e-7fd8-44d5-9549-ddbd6564e4dd)


